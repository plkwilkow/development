def doskonala(x):
    suma = 1
    for i in range(2, int(x)-1):
        if int(x) % i == 0:
            suma = suma + i
    return suma


print("Podaj liczbe")
x = input()
if int(x) == doskonala(x):
    print("Jest liczba doskonala")
else:
    print("Nie jest liczba doskonala")
