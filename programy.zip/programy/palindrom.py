def sort(slowo):
    slowo = slowo.replace(" ", "")
    slowo = slowo.upper()
    return slowo


print("podaj slowo")
slowo = input()
slowo = sort(slowo)
print(slowo)
if slowo == slowo[::-1]:
    print("Jest to palindrom")
else:
    print("To nie jest palindrom")
