print("Podaj liczbe")

x = input()

czy_pierwsza = bool('true')

if int(x) < 1:
    print("Liczby pierwsze sa wieksze od 1!")
else:
    for i in range(2, int(x)-1):
        if int(x) % i == 0:
            czy_pierwsza = 'false'
            break

    if czy_pierwsza == 'false':
        print("Nie jest liczba pierwsza")
    else:
        print("Jest pierwsza")
