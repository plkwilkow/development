def sort(slowo):
    slowo = slowo.replace(" ", "")
    slowo = slowo.upper()
    slowo = sorted(slowo)
    return slowo


print("podaj slowa")
slowo1 = input()
slowo2 = input()

slowo1 = sort(slowo1)
slowo2 = sort(slowo2)
print(slowo1)
print(slowo2)
if len(slowo1) != len(slowo2):
    print("To nie jest anagram")
elif slowo1 == slowo2:
    print("To jest anagram")
else:
    print("To nie jest anagram")
